var searchData=
[
  ['bases_2eh',['bases.h',['../bases_8h.html',1,'']]]
];
