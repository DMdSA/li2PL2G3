var searchData=
[
  ['jogada_5fintermedia',['jogada_Intermedia',['../logicaPrograma_8h.html#a2c0e7f4b070b426a1371bf87c252f434',1,'logicaPrograma.c']]],
  ['jogada_5fvencedora',['jogada_Vencedora',['../logicaPrograma_8h.html#aec4efd0d32feeb137bdcb3fbfdb5ffc2',1,'logicaPrograma.c']]]
];
