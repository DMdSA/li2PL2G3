var searchData=
[
  ['antecipa_5fpossibilidade_5fjogada',['antecipa_Possibilidade_Jogada',['../logicaPrograma_8h.html#adc388e0911e376ae7dd1e952032454a4',1,'logicaPrograma.h']]],
  ['atualiza_5fcasas',['atualiza_Casas',['../camadaDados_8h.html#a336a67cc7d708888b92440658026da07',1,'camadaDados.c']]],
  ['atualiza_5fjogador',['atualiza_Jogador',['../camadaDados_8h.html#a813951913df572df2226023bf1e05fd4',1,'camadaDados.c']]],
  ['atualiza_5fnum_5fjogadas',['atualiza_Num_Jogadas',['../camadaDados_8h.html#aceb02a965b878c96f606c41472e759b1',1,'camadaDados.c']]],
  ['atualiza_5fultima_5fjogada',['atualiza_Ultima_Jogada',['../camadaDados_8h.html#a9d6928e8fd855aef7b1dc49fd2c23612',1,'camadaDados.c']]]
];
