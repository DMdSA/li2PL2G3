var indexSectionsWithContent =
{
  0: "abcegijlmnoptuv",
  1: "cej",
  2: "bcil",
  3: "acgijlmopv",
  4: "jntu",
  5: "j",
  6: "c",
  7: "u"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "pages"
};

var indexSectionLabels =
{
  0: "Tudo",
  1: "Classes",
  2: "Ficheiros",
  3: "Funções",
  4: "Variáveis",
  5: "Definições de tipos",
  6: "Enumerações",
  7: "Páginas"
};

