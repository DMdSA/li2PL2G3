var searchData=
[
  ['inicializar_5festado',['inicializar_estado',['../camadaDados_8h.html#a7e0c7e26fb685d9ab501e19b05e6954f',1,'camadaDados.c']]],
  ['interfaceprograma_2eh',['interfacePrograma.h',['../interfacePrograma_8h.html',1,'']]]
];
