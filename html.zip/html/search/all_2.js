var searchData=
[
  ['camadadados_2eh',['camadaDados.h',['../camadaDados_8h.html',1,'']]],
  ['casa',['CASA',['../bases_8h.html#aba91601f16d4c485b2d9b8c429f27039',1,'bases.h']]],
  ['coordenada',['COORDENADA',['../structCOORDENADA.html',1,'']]],
  ['criar_5fcoordenada',['criar_Coordenada',['../camadaDados_8h.html#a46e323c064b73ec9a4269b0fe8341663',1,'camadaDados.c']]]
];
