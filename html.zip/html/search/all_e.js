var searchData=
[
  ['verifica_5fcasa',['verifica_CASA',['../logicaPrograma_8h.html#a3ce81cb71b8c83c612a45031aff80b30',1,'logicaPrograma.c']]],
  ['verifica_5fganhou',['verifica_GANHOU',['../logicaPrograma_8h.html#abaef7937ec567d297655312be67e4e6f',1,'logicaPrograma.c']]],
  ['verifica_5finicio_5fjogo',['verifica_Inicio_Jogo',['../camadaDados_8h.html#a6ad0222d4b62f1a7ca4436fc02b89136',1,'camadaDados.c']]],
  ['verifica_5fperdeu',['verifica_PERDEU',['../logicaPrograma_8h.html#a9483a3bd0778f067771a4e62af2cce8d',1,'logicaPrograma.c']]],
  ['verifica_5fposicao_5fjogada',['verifica_Posicao_Jogada',['../logicaPrograma_8h.html#a6169396bede24747c8bd74141cf1e606',1,'logicaPrograma.c']]]
];
