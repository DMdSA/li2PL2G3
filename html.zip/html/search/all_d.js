var searchData=
[
  ['uminho_5fli2',['Uminho_LI2',['../md_README.html',1,'']]],
  ['ultima_5fjogada',['ultima_jogada',['../structESTADO.html#a4896a5c5c1f40b43fb795623327e3f47',1,'ESTADO']]]
];
