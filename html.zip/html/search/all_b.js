var searchData=
[
  ['perdeste',['perdeste',['../camadaDados_8h.html#a61f5dacbfc0f1a717b90c0fdd4903242',1,'camadaDados.c']]],
  ['prompt_5finfo',['prompt_INFO',['../interfacePrograma_8h.html#a1b41ced8b3c6acd622e94ddafd58fa36',1,'interfacePrograma.c']]]
];
