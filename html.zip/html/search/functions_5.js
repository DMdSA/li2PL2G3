var searchData=
[
  ['ler',['ler',['../interfacePrograma_8h.html#ace9b5e2cbcfd1b464d3984f4d386d5ab',1,'interfacePrograma.c']]],
  ['letra_5fnumero',['letra_Numero',['../camadaDados_8h.html#a734ffc06918bef048887bf7b4377e22a',1,'camadaDados.c']]]
];
