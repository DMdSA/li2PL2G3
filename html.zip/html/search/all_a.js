var searchData=
[
  ['obter_5fcoluna_5fatual',['obter_Coluna_Atual',['../camadaDados_8h.html#a7b7576993c7b646f116e58ce05910158',1,'camadaDados.c']]],
  ['obter_5festado_5fcasa',['obter_estado_casa',['../camadaDados_8h.html#a6faa68373203923729ed38657aa0f768',1,'camadaDados.c']]],
  ['obter_5fjogador_5fatual',['obter_jogador_atual',['../camadaDados_8h.html#ad6e326e4ffa57ca1ae0c75377ecefc8c',1,'camadaDados.c']]],
  ['obter_5flinha_5fatual',['obter_Linha_Atual',['../camadaDados_8h.html#a1a05b5ca3eee4a805887c038d712bddc',1,'camadaDados.c']]],
  ['obter_5fnumero_5fde_5fjogadas',['obter_numero_de_jogadas',['../camadaDados_8h.html#a6cd0b387bdee9e18003c78852394aa63',1,'camadaDados.c']]],
  ['obter_5fultima_5fjogada',['obter_Ultima_Jogada',['../camadaDados_8h.html#a49f041543dcecd1cc75746f16fa3530b',1,'camadaDados.c']]]
];
