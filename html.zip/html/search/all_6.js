var searchData=
[
  ['jogada',['JOGADA',['../structJOGADA.html',1,'']]],
  ['jogada_5fintermedia',['jogada_Intermedia',['../logicaPrograma_8h.html#a2c0e7f4b070b426a1371bf87c252f434',1,'logicaPrograma.c']]],
  ['jogada_5fvencedora',['jogada_Vencedora',['../logicaPrograma_8h.html#aec4efd0d32feeb137bdcb3fbfdb5ffc2',1,'logicaPrograma.c']]],
  ['jogadas',['jogadas',['../structESTADO.html#afae43b87a488fad0f2b56a18bad31d18',1,'ESTADO::jogadas()'],['../bases_8h.html#a94c221d29a1760f008b7834093259b7d',1,'JOGADAS():&#160;bases.h']]],
  ['jogador_5fatual',['jogador_atual',['../structESTADO.html#a5dd28e2e68b7aef2b6b7ea88e02eff58',1,'ESTADO']]]
];
