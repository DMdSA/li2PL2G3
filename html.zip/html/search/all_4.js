var searchData=
[
  ['gr',['gr',['../interfacePrograma_8h.html#afed563ce7835513567489249b187f4a1',1,'interfacePrograma.c']]]
];
