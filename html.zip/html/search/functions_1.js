var searchData=
[
  ['criar_5fcoordenada',['criar_Coordenada',['../camadaDados_8h.html#a46e323c064b73ec9a4269b0fe8341663',1,'camadaDados.c']]]
];
