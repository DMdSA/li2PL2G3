//Tabuleiro Quadrado 8 por 8


//			0	1	2	3	4	5	6	7							
//		0	.	.	.	.	.	.	.	[2]
//		
//		1	.	.	.	.	.	.	.	.
//		
//		2	.	.	.	.	.	.	.	.
//		
//		3	.	.	.	.	*	.	.	.
//		
//		4	.	.	.	.	.	.	.	.
//
//		5	.	.	.	.	.	.	.	.
//		
//		6	.	.	.	.	.	.	.	.
//		
//		7	[1]	.	.	.	.	.	.	.


// Cada casa vazia tem um .'

// Cada casa antiga tem um '#'

// Cada casa atual tem um '*'

// A configuração inicial é ([3],[4]) !!!!!